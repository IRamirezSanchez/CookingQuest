package com.example.test_test_to_speech;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.HashMap;
import java.util.Locale;

//Error: Play/Pause hay que darle 2 veces para que se reproduzca despues de darle al Next (Hay que mirarlo).

public class MainActivity extends AppCompatActivity {
    private ProgressBar progressBar;
    private TextToSpeech textToSpeech;
    private int currentProgress = 0;
    private TextView step1Label, step2Label, step3Label, step4Label;
    private Button stopButton;
    private Button playPauseButton;
    private Button nextButton;
    private boolean isPlaying = false;
    private boolean buttonClicked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progressBar);
        step1Label = findViewById(R.id.step1Label);
        step2Label = findViewById(R.id.step2Label);
        step3Label = findViewById(R.id.step3Label);
        step4Label = findViewById(R.id.step4Label);
        stopButton = findViewById(R.id.stopButton);
        playPauseButton = findViewById(R.id.playPauseButton);
        nextButton = findViewById(R.id.nextButton);

        progressBar.setMax(100);
        progressBar.setProgress(0);

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stopSpeech();
            }
        });

        playPauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                togglePlayPause();
            }
        });

        textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    Locale spanish = new Locale("es", "ES");
                    textToSpeech.setLanguage(spanish);
                }
            }
        });

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isPlaying) {
                    buttonClicked = true;
                    updateProgressBarAndSpeak();
                }
            }
        });
    }

    private void stopSpeech() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            currentProgress = 0;
            progressBar.setProgress(currentProgress);
            updateLabelsVisibility();
            isPlaying = false;
            updatePlayPauseButtonIcon();
        }
    }

    private void stopSpeech2() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            if (currentProgress == 25) {
                currentProgress = 0;
                step1Label.setVisibility(View.VISIBLE);
                step2Label.setVisibility(View.INVISIBLE);
                step3Label.setVisibility(View.INVISIBLE);
                step4Label.setVisibility(View.INVISIBLE);
            } else if (currentProgress == 50) {
                currentProgress = 25;
                step1Label.setVisibility(View.INVISIBLE);
                step2Label.setVisibility(View.VISIBLE);
                step3Label.setVisibility(View.INVISIBLE);
                step4Label.setVisibility(View.INVISIBLE);
            } else if (currentProgress == 75) {
                currentProgress = 50;
                step1Label.setVisibility(View.INVISIBLE);
                step2Label.setVisibility(View.INVISIBLE);
                step3Label.setVisibility(View.VISIBLE);
                step4Label.setVisibility(View.INVISIBLE);
            } else if (currentProgress == 100) {
                currentProgress = 75;
                step1Label.setVisibility(View.INVISIBLE);
                step2Label.setVisibility(View.INVISIBLE);
                step3Label.setVisibility(View.INVISIBLE);
                step4Label.setVisibility(View.VISIBLE);
            }
            isPlaying = false;
            updatePlayPauseButtonIcon();
            enableNextButton();
        }
    }

    private void updateLabelsVisibility() {
        step1Label.setVisibility(View.VISIBLE);
        step2Label.setVisibility(View.INVISIBLE);
        step3Label.setVisibility(View.INVISIBLE);
        step4Label.setVisibility(View.INVISIBLE);
    }

    private void updateProgressBarAndSpeak() {
        if (currentProgress == 0 || currentProgress == 100) {
            currentProgress = 25;
            step1Label.setVisibility(View.VISIBLE);
            step2Label.setVisibility(View.INVISIBLE);
            step3Label.setVisibility(View.INVISIBLE);
            step4Label.setVisibility(View.INVISIBLE);
        } else if (currentProgress == 25) {
            currentProgress = 50;
            step1Label.setVisibility(View.INVISIBLE);
            step2Label.setVisibility(View.VISIBLE);
            step3Label.setVisibility(View.INVISIBLE);
            step4Label.setVisibility(View.INVISIBLE);
        } else if (currentProgress == 50) {
            currentProgress = 75;
            step1Label.setVisibility(View.INVISIBLE);
            step2Label.setVisibility(View.INVISIBLE);
            step3Label.setVisibility(View.VISIBLE);
            step4Label.setVisibility(View.INVISIBLE);
        } else if (currentProgress == 75) {
            currentProgress = 100;
            step1Label.setVisibility(View.INVISIBLE);
            step2Label.setVisibility(View.INVISIBLE);
            step3Label.setVisibility(View.INVISIBLE);
            step4Label.setVisibility(View.VISIBLE);
        }

        progressBar.setProgress(currentProgress);

        if (isPlaying) {
            speakCurrentText();
        }
    }

    private void speakCurrentText() {
        String textToSpeak = getCurrentText();
        if (textToSpeak != null && !textToSpeak.isEmpty()) {
            HashMap<String, String> params = new HashMap<>();
            params.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "ReproducirTexto");
            textToSpeech.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, params);
        }
    }

    private String getCurrentText() {
        String currentText = "";
        switch (currentProgress) {
            case 25:
                currentText = getString(R.string.texto1);
                break;
            case 50:
                currentText = getString(R.string.texto2);
                break;
            case 75:
                currentText = getString(R.string.texto3);
                break;
            case 100:
                currentText = getString(R.string.texto4);
                break;
        }
        return currentText;
    }

    private void togglePlayPause() {
        if (!buttonClicked) {
            if (isPlaying) {
                pauseSpeech();
            } else {
                if (currentProgress != 100) {
                    playSpeech();
                }
            }
            updatePlayPauseButtonIcon();
        }
        buttonClicked = false;
    }


    public void onClickPlayPause(View view) {
        togglePlayPause();
    }

    private void playSpeech() {
        isPlaying = true;
        updateProgressBarAndSpeak();
        nextButton.setEnabled(false);
    }


    private void pauseSpeech() {
        isPlaying = false;
        stopSpeech2();
        enableNextButton();
    }
    private void enableNextButton() {
        nextButton.setEnabled(true);
    }


    private void updatePlayPauseButtonIcon() {
        int iconResourceId = isPlaying ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play;
        playPauseButton.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId, 0, 0);
    }

    @Override
    protected void onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }
}
