package com.example.test_test_to_speech;
import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.common.model.RemoteModelManager;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.TranslateRemoteModel;
import com.google.mlkit.nl.translate.Translation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.util.HashMap;
import java.util.Locale;

/**
 * Esta clase representa una actividad que maneja varios botones para reproducir
 * texto en voz y realizar traducción de texto.
 */
public class VariosButtons extends AppCompatActivity {

    // Variables miembro

    private TextToSpeech textToSpeech; // Objeto para convertir texto a voz
    private Button playPauseButton1, playPauseButton2, playPauseButton3, playPauseButton4, playPauseButton5; // Botones para reproducir/pausar el texto
    private String texto_1, texto_2, texto_3, texto_4, texto_5; // Texto a ser reproducido
    private boolean isPlaying = false; // Estado de reproducción
    private int whichButtonClicked; // Índice del botón clicado
    private Translator translator; // Objeto para realizar traducción de texto
    private Button translateButtonEs; // Botón para iniciar la traducción
    private Button translateButtonIn; // Botón para iniciar la traducción
    private boolean isTranslatedToSpanish = true; // Estado de traducción
    private boolean isTranslatedToEnglish = false; // Estado de traducción
    private boolean isSpainFlag = true; // Indicador de la bandera actual (España o Inglaterra)

    // Métodos

    /**
     * Método llamado cuando la actividad se está creando.
     * Se inicializan los elementos de la interfaz de usuario y se configuran los listeners.
     *
     * @param savedInstanceState La instancia previamente guardada del estado de la actividad.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_varios_buttons);

        // Inicializar botones y texto
        playPauseButton1 = findViewById(R.id.playPauseButton1);
        playPauseButton2 = findViewById(R.id.playPauseButton2);
        playPauseButton3 = findViewById(R.id.playPauseButton3);
        playPauseButton4 = findViewById(R.id.playPauseButton4);
        playPauseButton5 = findViewById(R.id.playPauseButton5);
        translateButtonEs = findViewById(R.id.translateButtonEs);
        translateButtonIn = findViewById(R.id.translateButtonIn);
        texto_1 = getString(R.string.texto1);
        texto_2 = getString(R.string.texto2);
        texto_3 = getString(R.string.texto3);
        texto_4 = getString(R.string.texto4);
        texto_5 = getString(R.string.texto5);

        // Configurar listeners para los botones
        setButtonClickListener(playPauseButton1, 1);
        setButtonClickListener(playPauseButton2, 2);
        setButtonClickListener(playPauseButton3, 3);
        setButtonClickListener(playPauseButton4, 4);
        setButtonClickListener(playPauseButton5, 5);

        // Inicializar TextToSpeech para convertir texto a voz
        textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {
                    Locale spanish = new Locale("es", "ES");
                    textToSpeech.setLanguage(spanish);
                }
            }
        });

        // Inicializar el traductor
        TranslatorOptions options =
                new TranslatorOptions.Builder()
                        .setSourceLanguage(TranslateLanguage.SPANISH) // Establece el idioma de origen en español
                        .setTargetLanguage(TranslateLanguage.ENGLISH) // Establece el idioma de destino en inglés
                        .build();
        translator = Translation.getClient(options);


        // Configurar el listener para el botón de traducción al inglés
        translateButtonIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isTranslatedToSpanish) {
                    translateTextIn();
                    isTranslatedToSpanish = false;
                    isTranslatedToEnglish = true;
                }
            }
        });

        // Configurar el listener para el botón de traducción al español
        translateButtonEs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isTranslatedToEnglish) {
                    translateTextEs();
                    isTranslatedToEnglish = false;
                    isTranslatedToSpanish = true;
                }
            }
        });
    }


    ///////////////////////////////////////[TRANSLATE]/////////////////////////////////////////
    /**
     * Método para traducir el texto a Español.
     * Se descarga el modelo de traducción si es necesario y se realiza la traducción.
     */
    private void translateTextEs() {
        // Agrega las condiciones de descarga para asegurarse de que el modelo esté disponible
        DownloadConditions conditions = new DownloadConditions.Builder()
                .requireWifi()
                .build();

        // Descarga el modelo si es necesario
        translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        translateStepsToSpanish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // Error al descargar el modelo
                        Log.e(TAG, "Error al descargar el modelo de traducción: " + e.getMessage());
                    }
                });
    }

    /**
     * Método para traducir el texto a Ingles.
     * Se descarga el modelo de traducción si es necesario y se realiza la traducción.
     */
    private void translateTextIn() {
        // Agrega las condiciones de descarga para asegurarse de que el modelo esté disponible
        DownloadConditions conditions = new DownloadConditions.Builder()
                .requireWifi()
                .build();

        // Descarga el modelo si es necesario
        translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        translateStepsToEnglish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // Error al descargar el modelo
                        Log.e(TAG, "Error al descargar el modelo de traducción: " + e.getMessage());
                    }
                });
    }

    /**
     * Método para traducir los pasos al inglés.
     */
    private void translateStepsToEnglish() {
        // Traduce cada preparación al inglés
        translateStepToEnglish(texto_1, R.id.textView1);
        translateStepToEnglish(texto_2, R.id.textView2);
        translateStepToEnglish(texto_3, R.id.textView3);
        translateStepToEnglish(texto_4, R.id.textView4);
        translateStepToEnglish(texto_5, R.id.textView5);
    }

    /**
     * Método para traducir los pasos al español.
     */
    private void translateStepsToSpanish() {
        // Restaura el texto original en español para cada preparación
        translateStepToSpanish(texto_1, R.id.textView1);
        translateStepToSpanish(texto_2, R.id.textView2);
        translateStepToSpanish(texto_3, R.id.textView3);
        translateStepToSpanish(texto_4, R.id.textView4);
        translateStepToSpanish(texto_5, R.id.textView5);
    }

    /**
     * Método para traducir un paso al inglés.
     *
     * @param originalText El texto original a traducir.
     * @param textViewId   El ID del TextView donde se mostrará la traducción.
     */
    private void translateStepToEnglish(String originalText, final int textViewId) {
        translator.translate(originalText)
                .addOnSuccessListener(new OnSuccessListener<String>() {
                    @Override
                    public void onSuccess(String translatedText) {
                        // Actualiza el texto traducido en la interfaz de usuario
                        TextView preparacionTextView = findViewById(textViewId);
                        preparacionTextView.setText(translatedText);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // Error al traducir
                        Log.e(TAG, "Error al traducir la preparación: " + e.getMessage());
                    }
                });
    }

    /**
     * Método para restaurar un paso al español.
     *
     * @param originalText El texto original a restaurar.
     * @param textViewId   El ID del TextView donde se mostrará el texto original.
     */
    private void translateStepToSpanish(String originalText, final int textViewId) {
        // Restaura el texto original en español para cada preparación
        TextView preparacionTextView = findViewById(textViewId);
        preparacionTextView.setText(originalText);
    }


    ///////////////////////////////////////[TEXT_TO_SPEECH]/////////////////////////////////////////
    /**
     * Método para configurar un listener para un botón específico.
     *
     * @param button       El botón al que se le configurará el listener.
     * @param buttonNumber El número del botón.
     */
    private void setButtonClickListener(Button button, final int buttonNumber) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                whichButtonClicked = buttonNumber; // Actualiza el botón clicado antes de togglePlayPause
                if (isPlaying && whichButtonClicked != buttonNumber) {
                    stopSpeech();
                    updatePlayPauseButtonIcon(whichButtonClicked);
                } else {
                    togglePlayPause();
                }
                updatePlayPauseButtonIcon(whichButtonClicked); // Actualiza el icono después de togglePlayPause
            }
        });
    }

    /**
     * Método para detener la reproducción de voz.
     */
    private void stopSpeech() {
        if (textToSpeech != null) {
            textToSpeech.stop();
        }
        isPlaying = false; // Actualiza el estado después de detener la reproducción
    }

    /**
     * Método para alternar entre reproducir y pausar la voz.
     */
    private void togglePlayPause() {
        if (isPlaying) {
            pauseSpeech();
        } else {
            playSpeech();
        }
    }

    /**
     * Método para iniciar la reproducción de voz.
     */
    private void playSpeech() {
        isPlaying = true;
        speakCurrentText();
    }

    /**
     * Método para pausar la reproducción de voz.
     */
    private void pauseSpeech() {
        isPlaying = false;
        stopSpeech();
    }

    /**
     * Método para hablar el texto actual.
     */
    private void speakCurrentText() {
        String textToSpeak = getCurrentText();
        if (textToSpeak != null && !textToSpeak.isEmpty()) {
            HashMap<String, String> params = new HashMap<>();
            params.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "ReproducirTexto");
            textToSpeech.speak(textToSpeak, TextToSpeech.QUEUE_ADD, params);
        }
    }

    /**
     * Método para obtener el texto actual a ser hablado.
     *
     * @return El texto actual a ser hablado.
     */
    private String getCurrentText() {
        String currentText = "";
        switch (whichButtonClicked) {
            case 1:
                currentText = getString(R.string.texto1);
                break;
            case 2:
                currentText = getString(R.string.texto2);
                break;
            case 3:
                currentText = getString(R.string.texto3);
                break;
            case 4:
                currentText = getString(R.string.texto4);
                break;
            case 5:
                currentText = getString(R.string.texto5);
                break;
        }
        return currentText;
    }

    /**
     * Método para actualizar el ícono del botón de reproducción/pausa.
     *
     * @param buttonNumber El número del botón.
     */
    private void updatePlayPauseButtonIcon(int buttonNumber) {
        int iconResourceId = isPlaying ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play;
        int iconResourceId2 = android.R.drawable.ic_media_play;
        switch (buttonNumber) {
            case 1:
                playPauseButton1.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId, 0, 0);
                playPauseButton2.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                playPauseButton3.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                playPauseButton4.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                playPauseButton5.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                break;
            case 2:
                playPauseButton1.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                playPauseButton2.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId, 0, 0);
                playPauseButton3.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                playPauseButton4.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                playPauseButton5.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                break;
            case 3:
                playPauseButton1.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                playPauseButton2.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                playPauseButton3.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId, 0, 0);
                playPauseButton4.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                playPauseButton5.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                break;
            case 4:
                playPauseButton1.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                playPauseButton2.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                playPauseButton3.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);


                playPauseButton4.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId, 0, 0);
                playPauseButton5.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                break;
            case 5:
                playPauseButton1.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                playPauseButton2.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                playPauseButton3.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                playPauseButton4.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId2, 0, 0);
                playPauseButton5.setCompoundDrawablesWithIntrinsicBounds(0, iconResourceId, 0, 0);
                break;
        }
    }

    /**
     * Método llamado cuando la actividad está siendo destruida.
     * Se detiene la reproducción de voz y se libera los recursos del TextToSpeech.
     */
    @Override
    protected void onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }
}